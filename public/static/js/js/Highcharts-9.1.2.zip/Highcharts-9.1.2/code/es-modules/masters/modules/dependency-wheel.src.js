/**
 * @license Highcharts JS v9.1.2 (2021-06-16)
 * @module highcharts/modules/dependency-wheel
 * @requires highcharts
 * @requires highcharts/modules/sankey
 *
 * Dependency wheel module
 *
 * (c) 2010-2021 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Series/DependencyWheel/DependencyWheelSeries.js';
