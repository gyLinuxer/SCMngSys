/**
 * @license Highcharts Gantt JS v9.1.2 (2021-06-16)
 * @module highcharts/modules/pathfinder
 * @requires highcharts
 *
 * Pathfinder
 *
 * (c) 2016-2021 Øystein Moseng
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Gantt/Pathfinder.js';
