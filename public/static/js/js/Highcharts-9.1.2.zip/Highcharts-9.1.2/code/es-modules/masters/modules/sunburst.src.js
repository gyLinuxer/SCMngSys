/**
 * @license Highcharts JS v9.1.2 (2021-06-16)
 * @module highcharts/modules/sunburst
 * @requires highcharts
 *
 * (c) 2016-2021 Highsoft AS
 * Authors: Jon Arild Nygard
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Series/Treemap/TreemapSeries.js';
import '../../Series/Sunburst/SunburstSeries.js';
