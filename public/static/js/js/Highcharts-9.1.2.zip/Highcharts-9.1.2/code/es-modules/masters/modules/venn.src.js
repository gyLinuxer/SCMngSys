/**
 * @license Highcharts JS v9.1.2 (2021-06-16)
 * @module highcharts/modules/venn
 * @requires highcharts
 *
 * (c) 2017-2021 Highsoft AS
 * Authors: Jon Arild Nygard
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Series/Venn/VennSeries.js';
